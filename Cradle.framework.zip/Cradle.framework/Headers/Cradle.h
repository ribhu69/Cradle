//
//  Cradle.h
//  Cradle
//
//  Created by Arkaprava Ghosh on 17/01/24.
//

#import <Foundation/Foundation.h>

//! Project version number for Cradle.
FOUNDATION_EXPORT double CradleVersionNumber;

//! Project version string for Cradle.
FOUNDATION_EXPORT const unsigned char CradleVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Cradle/PublicHeader.h>


